<div class="menus"><a href="./memo/memo.php"><img src="./img/menu01.gif" border="0"></a></div>
<div class="menus"><a href="./memo_build/memo_build.php"><img src="./img/menu02.gif" border="0"></a></div>
<div class="menus"><a href="./weather/weather.php"><img src="./img/menu03.gif" border="0"></a></div>
<div class="menus"><a href="./report/reprot.php"><img src="./img/menu04.gif" border="0"></a></div>
