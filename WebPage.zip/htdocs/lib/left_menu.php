		<div id="sub_title">
 			<img src="../img/title_left_menu.gif">
		</div>
		<ul>
		<li>알림(교직원)</li>
		<li>알림(공사관리자)</li>
		<li>기상알림</li>
		<li>버그리포트</li>
		</ul>