create table busi_1 (

log_num int not null auto_increment,
b_location char(10),
b_temper float,
b_moist float,
calcul_time timestamp,
primary key(log_num)
);

create table busi_2 ( 

log_num int not null auto_increment,
b_location char(10),
b_temper float,
b_moist float,
calcul_time timestamp,
primary key(log_num)
);

create table busi_3 (

log_num int not null auto_increment,
b_location char(10),
b_temper float,
b_moist float,
calcul_time timestamp,
primary key(log_num)

);