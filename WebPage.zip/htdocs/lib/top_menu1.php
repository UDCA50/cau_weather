
<div class="menus"><a href="./memo/memo.php"><img src="./img/menu01.jpg" border="0"></a></div>
<div class="menus"><a href="./memo_build/memo_build.php"><img src="./img/menu02.jpg" border="0"></a></div>
<div class="menus"><a href="./weather/weather.php"><img src="./img/menu03.jpg" border="0"></a></div>
<div class="menus"><a href="./report/report.php"><img src="./img/menu04.jpg" border="0"></a></div>
